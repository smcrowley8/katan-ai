# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['katan_ai', 'katan_ai.commands', 'katan_ai.katan', 'katan_ai.katan.board']

package_data = \
{'': ['*']}

install_requires = \
['click>=8.0.3,<9.0.0',
 'colored>=1.4.3,<2.0.0',
 'inputs>=0.5,<0.6',
 'numpy>=1.22.1,<2.0.0',
 'pre-commit>=2.17.0,<3.0.0',
 'requests>=2.27.1,<3.0.0',
 'rich>=11.0.0,<12.0.0',
 'selenium>=4.1.0,<5.0.0',
 'webdriver-manager>=3.5.2,<4.0.0']

entry_points = \
{'console_scripts': ['katanAI = katan_ai.main:cli']}

setup_kwargs = {
    'name': 'katan-ai',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Katan AI\n\nTable of contents:\n\n- [Installation](#Installation)\n- [Guide](#Guide)\n- [Developement](#Developement)\n\n# Installation\nrequires python 3.8\n```bash\npip install poetry\npoetry install\n#TODO\n```\n\n# Guide\n\n<!-- Subsection explaining how to use package -->\n\n# Developement\nTo develop, install dependencies and enable pre-commit hooks.\n\n\n```bash\npip install -U pip\npip install poetry pre-commit\npoetry install\npre-commit install -t pre-commit -t pre-push\n```\n\n\nFor more on developing/contributing see [link](https://github.com/smcrowley8/katan-ai/tree/main/docs/dev/contributing.md)\n\n',
    'author': 'Sean Crowley',
    'author_email': 'smcrowley8@gmail.com',
    'maintainer': 'Sean Crowleu',
    'maintainer_email': 'smcrowley8@gmail.com',
    'url': 'https://github.com/smcrowley8/myAES',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
