"""module for CLI and abstract game commands"""
